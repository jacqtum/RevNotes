package com.revature.dao;

import java.sql.SQLException;
import java.util.List;

import com.revature.herojdbc.beans.Hero;

public interface PowersDAO {

	public abstract void createPower(String powerName) throws SQLException; 
		// throws Exception so when implemented by a class, the class will also have throws SQLException.
		// won't need to add try/catch block
	
	public abstract List<Hero> getSuperHeroList() throws SQLException;
	
	
}
