package com.revature.herojdbc;

/**
 * Hello world!
 *
 */
public class App 
{
//    public static void main( String[] args )
//    {
//    	// Run -> Run Configurations -> Argument -> Program Argument -> hello
//        System.out.println(args[0] );
//    }
}
